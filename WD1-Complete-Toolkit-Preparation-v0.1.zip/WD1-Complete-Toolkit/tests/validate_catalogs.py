"""Validate project data consistency; no network or game access."""
from pathlib import Path
import csv
import json

root = Path(__file__).resolve().parents[1]
achievements = json.loads((root / 'data/achievements.json').read_text(encoding='utf-8'))['items']
features = json.loads((root / 'data/feature_requirements.json').read_text(encoding='utf-8'))['items']
project = json.loads((root / 'project.json').read_text(encoding='utf-8'))

assert len(achievements) == 49
assert len({a['steam_display_name'] for a in achievements}) == 49
assert len({a['project_id'] for a in achievements}) == 49
assert sum(a['content_pack'] == 'Base game' for a in achievements) == 39
assert sum(a['content_pack'] == 'Bad Blood' for a in achievements) == 10
assert sum(a['normal_gameplay_requires_multiplayer'] for a in achievements) == 6
assert {a['steam_display_name'] for a in achievements if a['normal_gameplay_requires_multiplayer']} == {
    'Hackification', 'Piggyback', 'Superhighway', 'Stealth Cookie', 'Traced', 'T-Bone: Tag Team'
}
assert all(a['steam_api_name'] is None for a in achievements), 'Do not invent Steam API names'
assert all(a['implementation_status'] == 'catalog_only_not_implemented' for a in achievements)
assert len(features) == 150
assert len({f['id'] for f in features}) == len(features)
assert all(f['evidence_class'] in {'T', 'D', 'U', 'R', 'E'} for f in features)
assert not project['is_finished_trainer']
assert project['game_write_features_implemented'] == 0
assert project['supported_game_fingerprints'] == []

for filename, expected in [('achievements.csv', 49), ('feature_requirements.csv', 150), ('online_rewards.csv', 8)]:
    with (root / 'data' / filename).open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == expected, filename
    assert all(None not in r for r in rows), f'Malformed CSV: {filename}'
    assert all(not str(v).startswith(('=', '+', '@')) for row in rows for v in row.values()), 'Unexpected spreadsheet formula'

print('PASS: 49 achievements (39 base + 10 DLC), 6 multiplayer, 150 requirements, 8 reward mappings.')
print('PASS: No invented Steam API names, supported game fingerprints or finished-trainer claims.')
