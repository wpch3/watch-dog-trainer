"""Static release/catalog/contract validation. No game or network access."""
from pathlib import Path
import csv,json,re,struct,hashlib
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
a=load('data/achievements.json')['items'];f=load('data/feature_requirements.json')['items'];p=load('project.json');items=load('data/runtime_items.json')['items']
assert len(a)==49 and len({x['steam_display_name'] for x in a})==49
assert len({x['project_id'] for x in a})==49
assert sum(x['content_pack']=='Base game' for x in a)==39
assert sum(x['content_pack']=='Bad Blood' for x in a)==10
assert {x['steam_display_name'] for x in a if x['normal_gameplay_requires_multiplayer']}=={'Hackification','Piggyback','Stealth Cookie','Traced','Superhighway','T-Bone: Tag Team'}
assert all(x['steam_api_name'] is None for x in a),'Reference file must not invent actual Steam API identifiers'
assert all(x['implementation_status']=='dynamic_client_workflow_implemented_runtime_unverified' for x in a)
assert len(f)==150 and len({x['id'] for x in f})==150
assert all(x['evidence_class'] in {'T','D','U','R','E'} for x in f)
assert all(x['delivery_v02'] in {'NOT_IMPLEMENTED','PARTIAL_UNVERIFIED','IMPLEMENTED_UNVERIFIED','READ_ONLY_USER_RUN','REFERENCE_COMPLETE'} for x in f)
assert not p['is_finished_trainer'] and p['game_runtime_verified_features']==0
assert p['supported_game_fingerprints']==[],'Observed hashes are not certified supported hashes'
assert p['game_write_features_implemented']==len(p['implemented_game_action_families'])==11
assert not p['candidate_third_party_host']['bundled'] and not p['candidate_third_party_host']['compatibility_verified']
assert len(items)==212 and len({i['key'] for i in items})==212
assert all(i['db_path']=='Items.'+i['key'] and re.fullmatch(r'\d+',i['key']) for i in items)
for i in items:
 assert i['source_category'] not in {'AccessIds','custom_Weapon','MissionSpecific','MainMissionXP','SideMissionXP'}
 assert i['status']=='IMPLEMENTED_UNVERIFIED' and i['mode'] in {'both','campaign','dlc_solo'}
 if i['source_category']=='Weapon':
  assert not any(s in i['db_name'] for s in ['.Empty','_MP','.NPC','.07_','ARReplicaWeapon','ChopperSniper','ClaraGun'])
keys={i['key']:i for i in items}
for key,name in {'2207476061':'AssaultRifles.OCP11','4099987261':'SMGs.MP9mm','770883049':'Shotguns.SG590','309961700':'SMGs.Vector45ACP.SpecOps','2023158576':'Skillpoint','678076169':'Generic.Speed.Speed_05_Reward'}.items():assert keys[key]['db_name']=='Items.'+name
assert sum(i['group']=='songs' for i in items)==22
assert all('Goodmorningsunshine' not in i['db_name'] for i in items)
for name,expected in [('achievements.csv',49),('feature_requirements.csv',150),('online_rewards.csv',8),('runtime_items.csv',212)]:
 with (R/'data'/name).open(encoding='utf-8-sig',newline='') as h:rows=list(csv.DictReader(h))
 assert len(rows)==expected and all(None not in row for row in rows)
 assert all(not str(v).startswith(('=','+','@')) for row in rows for v in row.values())
 for values in rows:
  assert all('\x00' not in str(v) for v in values.values())
profile=load('profiles/steam-11241563-observed.json')
cs=(R/'src/Shared/Files.cs').read_text()
for digest in profile['binary_sha256'].values():assert digest in cs and re.fullmatch('[A-F0-9]{64}',digest)
assert profile['diagnostic_save_candidates']==0 and not profile['progression_counters_in_report']
core=(R/'src/Plugin/core.lua').read_text();adapter=(R/'src/Plugin/menu.lua').read_text()
assert 'self:invoke("AddItem",job.name,job.quantity)' in core
assert 'self:invoke("GiveCash",0,job.quantity)' in core
assert 'self:invoke("FelonySetHeat",self:player(),n)' in core
assert 'self:invoke("GetEntityPosition",p,axis)' in core
assert 'if self.flags.focus then' in core
assert 'self:can(name=="ammo")' in core and 'AMMO_TICKET_INVALID' in core
assert 'function script:OnPause()' in adapter and 'function script:OnResume()' in adapter
assert 'REQUEST_SUBMITTED' in core and 'readback=UNAVAILABLE' in core
for mode in ['campaign','dlc_solo']:
 module='wd1kit_'+mode;root=R/'payload'/module
 m=json.loads((root/'modconfig.json').read_text())
 assert m['friendlyId']==module and m['compatibleGameModes']==[mode] and m['minTntVersion']=='1.1.12'
 assert m['packs']==[] and m['luaAutoStart']==[module+'/entrypoint.lua']
 for src in ['core.lua','menu.lua','catalog.lua']:assert (root/'workspace'/module/src).read_bytes()==(R/'src/Plugin'/src).read_bytes()
 assert 'allow_persistent=false' in (root/'workspace'/module/'receipt.lua').read_text()
 assert 'backup_id=' not in (root/'workspace'/module/'receipt.lua').read_text()
steamsrc='\n'.join(x.read_text() for x in (R/'src/Steam').glob('*.cs'))
assert 'SetAchievement(id,true)' in steamsrc
assert not re.search(r'\.(ResetAllStats|ClearAchievement|SetStatValue)\s*\(',steamsrc)
assert '243470' in steamsrc and 'UserGameStatsSchema_243470.bin' in steamsrc
assert 'p.GameId==AppId&&p.SteamIdUser==initialUser' in steamsrc
assert 'p.GameId==AppId&&Stored!=null' in steamsrc
assert 'CallbackResult' in steamsrc and 'TIMEOUT_UNCERTAIN' in steamsrc
assert 'protected' in steamsrc.lower() and 'Rows.Count!=49' in steamsrc
assert '#if !WD1KIT_FIXTURES' in cs and 'skipIdentityForFixture' not in cs
assert 'WD1KIT_FIXTURES' not in (R/'tools/build_release.py').read_text()
for file,machine in [('WD1-Toolkit.exe',0x8664),('WD1-Achievements.exe',0x14c),('WD1.SteamBridge.dll',0x14c)]:
 b=(R/file).read_bytes();assert b[:2]==b'MZ';offset=struct.unpack_from('<I',b,0x3c)[0]
 assert b[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',b,offset+4)[0]==machine
 assert len(b)>10000
legacy=(R/'tools/Collect-WD1Info.ps1').read_bytes()
assert hashlib.sha256(legacy).hexdigest()=='e95e7fd4e12b1adaba077e13a21a6fdbd11287ec9f1f00507ef6dcacf4f03ece'
assert legacy.startswith(b'\xef\xbb\xbf')
for path in R.rglob('*.json'):
 if not any(s in path.parts for s in ['reports','backups','private-saves']):json.loads(path.read_text(encoding='utf-8-sig'))
results=load('release-tests/results.json')
assert results['lua_51_fixture_checks']==126 and results['csharp_fixture_checks']==86
assert 'LUA_FIXTURE_CHECKS=126' in (R/'release-tests/lua-fixtures.log').read_text()
assert 'CSHARP_FIXTURE_CHECKS=86' in (R/'release-tests/csharp-fixtures.log').read_text()
assert not results['real_game_test'] and not results['real_steam_client_test']
print('PASS: 49 achievements / 150 requirements / 212 curated keys, CSV + JSON + payload parity.')
print('PASS: WD1-specific numeric item signatures, mode/receipt gates, no invented Steam API names.')
print('PASS: Windows PE x64/x86 binaries, real release gate contract, unchanged legacy collector.')
print('PASS: Implemented-vs-verified separation, test counts, no finished-trainer or runtime-support claim.')
