// Fixture-only test runner. Never selects or modifies a real game/account.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using WD1Kit;
using WD1Kit.Steam;
using SAM.Game;
namespace WD1Kit.Tests {
    class FakeStats:IStats {
        public event Action<int> Received;public event Action<int> Stored;
        public bool Context=true,ReadOK=true,RequestOK=true,StoreOK=true;public int Sets,Stores,Requests;
        public Dictionary<string,bool> Values=new Dictionary<string,bool>();public HashSet<string> Reject=new HashSet<string>();
        public bool ContextOK(){return Context;} public bool Request(){Requests++;return RequestOK;}
        public bool Get(string id,out bool val,out uint time){val=Values.ContainsKey(id)&&Values[id];time=val?100u:0;return ReadOK;}
        public bool Set(string id){Sets++;if(Reject.Contains(id))return false;Values[id]=true;return true;}
        public bool Store(){Stores++;return StoreOK;}public void Pump(){}public void Dispose(){}
        public void Receive(int n=1){if(Received!=null)Received(n);}public void Complete(int n=1){if(Stored!=null)Stored(n);}
    }
    class Runner {
        static int count; static void Check(bool b,string name){if(!b)throw new Exception("FAIL "+name);Console.WriteLine("PASS "+name);count++;}
        static void Fails(Action a,string name){bool threw=false;try{a();}catch{threw=true;}Check(threw,name);}
        static void Put(string f,string data){Directory.CreateDirectory(Path.GetDirectoryName(f));File.WriteAllText(f,data);}
        static List<Definition> Defs(){return Enumerable.Range(0,49).Select(i=>new Definition{Id="FIXTURE_ONLY_"+i,EnglishName=i==0?"Hackification":"Fixture "+i,Permission=0}).ToList();}
        static Controller Ready(FakeStats f,List<Definition> defs=null,Action<object> save=null,Func<DateTime> clock=null){var c=new Controller(f,()=>defs??Defs(),new[]{new Hint{Name="Hackification",Description="fixture",Online=true}},save??(o=>{}),clock);c.Refresh();f.Receive();return c;}
        static KeyValue Node(string name,params KeyValue[] children){return new KeyValue{Name=name,Valid=true,Type=KeyValueType.None,Children=children.ToList()};}
        static KeyValue S(string n,string v){return new KeyValue{Name=n,Valid=true,Type=KeyValueType.String,Value=v};}
        static KeyValue I(string n,int v){return new KeyValue{Name=n,Valid=true,Type=KeyValueType.Int32,Value=v};}
        static int Main(string[] args){
            string project=Path.GetFullPath(args.Length==0?Directory.GetCurrentDirectory():args[0]);
            string root=Path.Combine(Path.GetTempPath(),"WD1KIT-fixtures-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
            try{
                string source=Path.Combine(root,"saves"),data=Path.Combine(root,"tool-data");
                Put(Path.Combine(source,"1.save"),"abc");Put(Path.Combine(source,"2.save"),"def");Put(Path.Combine(source,"1.save.upload"),"metadata");Put(Path.Combine(source,"unrelated.txt"),"KEEP");
                var store=new LocalStorage(data);
                Check(Files.Hash(Path.Combine(source,"1.save"))=="BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD","SHA-256 known vector");
                Check(store.SaveFiles(source).Count==3,"recognized saves and upload sidecar only");
                Check(!LocalStorage.IsSave("GamerProfile.xml"),"profile is not a save");
                Check(!LocalStorage.IsSave("Disrupt_b64.dll"),"DLL is not a save");
                Fails(()=>store.SaveFiles(root),"empty candidate is not a backup");
                Fails(()=>store.SaveFiles(data),"cannot back up own storage recursively");
                Fails(()=>Files.Leaf("../escape.save"),"path traversal rejected");Fails(()=>Files.Leaf("C:escape.save"),"alternate data stream / drive prefix rejected");
                Fails(()=>Files.Leaf("nested\\1.save"),"backslash traversal rejected");
                Check(Files.Full(Path.GetPathRoot(root))==Path.GetPathRoot(root),"path root preserved");
                var b=store.Backup(source);Check(b.Manifest.Files.Count==3,"backup snapshots exact list");
                Check(File.ReadAllText(Path.Combine(source,"1.save"))=="abc","backup leaves originals unchanged");
                Check(store.Verify(b.ManifestPath).Manifest.AppId==243470,"backup identity and hashes validated");
                string originalManifest=File.ReadAllText(b.ManifestPath);var marker=Files.Read<Dictionary<string,object>>(b.ManifestPath);marker.Remove("Product");Files.Write(b.ManifestPath,marker);Fails(()=>store.Verify(b.ManifestPath),"missing explicit backup product marker rejected");File.WriteAllText(b.ManifestPath,originalManifest);
                string receipt=store.Receipt(b,"campaign");Check(receipt.Contains("allow_persistent=true"),"verified backup authorizes receipt");Check(!receipt.Contains(source),"receipt contains no private save path");
                string backup1=Path.Combine(Path.GetDirectoryName(b.ManifestPath),"files","1.save");File.WriteAllText(backup1,"CORRUPT");Fails(()=>store.Verify(b.ManifestPath),"corrupted backup rejected");File.WriteAllText(backup1,"abc");
                var oldId=b.Manifest.Id;b.Manifest.CreatedUtc=DateTime.UtcNow.AddHours(-3).ToString("o");Files.Write(b.ManifestPath,b.Manifest);Fails(()=>store.Receipt(b,"campaign"),"old backup cannot mint fresh receipt");
                b=store.Backup(source);
                string wrong=Path.Combine(root,"other-saves");Put(Path.Combine(wrong,"1.save"),"OTHER");Fails(()=>store.Restore(b.ManifestPath,wrong),"cross-directory restore rejected");
                File.WriteAllText(Path.Combine(source,"1.save"),"new-1");File.WriteAllText(Path.Combine(source,"2.save"),"new-2");Put(Path.Combine(source,"3.save"),"new-slot");
                File.SetAttributes(Path.Combine(source,"1.save"),FileAttributes.ReadOnly);Fails(()=>store.Restore(b.ManifestPath,source),"read-only destination refused before restore writes");Check(File.ReadAllText(Path.Combine(source,"2.save"))=="new-2","read-only preflight leaves other files unchanged");File.SetAttributes(Path.Combine(source,"1.save"),FileAttributes.Normal);
                Fails(()=>store.Restore(b.ManifestPath,source,n=>{if(n==1)throw new IOException("fixture failure");}),"injected restore failure returns error");
                Check(File.ReadAllText(Path.Combine(source,"1.save"))=="new-1"&&File.ReadAllText(Path.Combine(source,"2.save"))=="new-2","partial restore rolled back");
                Check(File.Exists(Path.Combine(source,"3.save")),"rollback preserves extra slot");
                store.Restore(b.ManifestPath,source);Check(File.ReadAllText(Path.Combine(source,"1.save"))=="abc","restore succeeds");
                Check(!File.Exists(Path.Combine(source,"3.save")),"extra recognized slot removed only after backup");Check(File.ReadAllText(Path.Combine(source,"unrelated.txt"))=="KEEP","unrelated files untouched");
                Check(Directory.GetDirectories(Path.Combine(data,"backups")).Length>=4,"pre-restore snapshots retained");
                string game=Path.Combine(root,"fixture-game");Directory.CreateDirectory(Path.Combine(game,"data_win64"));Put(Path.Combine(game,"bin","Watch_Dogs.exe"),"FIXTURE EXE");Put(Path.Combine(game,"bin","Disrupt_b64.dll"),"FIXTURE DLL");Put(Path.Combine(game,"bin","uplay_r1_loader64.dll"),"FIXTURE LOADER");
                Check(!Identity.Check(game).Matches,"unknown real binary hashes rejected");Fails(()=>Identity.Require(game),"identity fail closed");
                string payload=Path.Combine(project,"payload");
                Fails(()=>store.Install(game,payload,null,false),"host not confirmed rejects fixture installation");
                store.Install(game,payload,null,true);string installed=Path.Combine(game,"data_win64","mods","wd1kit_campaign");
                Check(File.Exists(Path.Combine(installed,"modconfig.json")),"temporary plugin installed");
                string installedReceipt=Path.Combine(installed,"workspace","wd1kit_campaign","receipt.lua");Check(File.ReadAllText(installedReceipt).Contains("allow_persistent=false"),"temporary install has no persistent permission");
                Put(Path.Combine(installed,"my-custom-note.txt"),"PRESERVE USER EDIT");
                Fails(()=>store.Install(game,payload,null,true,n=>{if(n==1)throw new IOException("fixture swap failure");}),"two-module swap failure detected");
                Check(File.ReadAllText(Path.Combine(installed,"my-custom-note.txt"))=="PRESERVE USER EDIT","failed update restores old custom files");
                Check(File.Exists(Path.Combine(game,"data_win64","mods","wd1kit_dlc_solo","modconfig.json")),"second module restored after transaction failure");
                b=store.Backup(source);store.Install(game,payload,b,true);Check(File.ReadAllText(installedReceipt).Contains("allow_persistent=true"),"persistent install gets validated receipt");
                Put(Path.Combine(source,"new.save"),"new");Fails(()=>store.Install(game,payload,b,true),"new unbacked save file blocks installation");File.Delete(Path.Combine(source,"new.save"));
                File.WriteAllText(Path.Combine(source,"1.save"),"changed");Fails(()=>store.Install(game,payload,b,true),"changed save blocks stale backup authorization");File.WriteAllText(Path.Combine(source,"1.save"),"abc");
                store.RevokeReceipts(game);Check(File.ReadAllText(installedReceipt).Contains("allow_persistent=false"),"restore workflow can revoke both plugin receipts");
                store.Uninstall(game);Check(!Directory.Exists(installed),"uninstall removes own plugin only");Check(File.ReadAllText(Path.Combine(game,"bin","Disrupt_b64.dll"))=="FIXTURE DLL","game binary untouched through install/update/uninstall");
                Put(Path.Combine(installed,"foreign.txt"),"FOREIGN");Fails(()=>store.Install(game,payload,null,true),"foreign same-name plugin refused");Check(File.ReadAllText(Path.Combine(installed,"foreign.txt"))=="FOREIGN","foreign directory untouched");
                string log=Path.Combine(root,"host.log");Put(log,"[host] ACCOUNT SECRET\n[time] [WD1KIT] CAP AddItem,GetSkillPointCount\n[WD1KIT] ERROR C:\\Users\\SECRET\\file\n[WD1KIT] PLUGIN_LOADED version=0.2.0-alpha mode=campaign game_runtime_verified=false\n[OTHER] credentials\n");
                var safe=WD1Kit.MainForm.ExtractLog(log);Check(safe.Count==2,"only restricted plugin lines exported");Check(!string.Join("\n",safe).Contains("SECRET"),"host log path/account strings excluded");
                // Protected and asynchronous platform workflow.
                {var f=new FakeStats();var c=new Controller(f,Defs,new Hint[0],o=>{});Fails(()=>c.Unlock(new[]{"FIXTURE_ONLY_0"}),"Steam unlock before read refused");Check(f.Sets==0,"unread platform state makes zero writes");}
                {var f=new FakeStats();var c=Ready(f);Check(c.State==Phase.Ready&&c.Rows.Count==49,"49 real-shaped fixture entries read");Check(c.Rows[0].Online,"English title mapped to online reference");Check(f.Sets==0,"refresh is read only");Fails(()=>c.Unlock(new[]{"FAKE_ACH_001"}),"unknown API key refused");}
                {var f=new FakeStats();var defs=Defs();defs[1].Permission=1;defs[2].Trusted=true;defs[3].Permission=8;var c=Ready(f,defs);Fails(()=>c.Unlock(new[]{defs[0].Id,defs[1].Id}),"protected mixed batch wholly refused");Fails(()=>c.Unlock(new[]{defs[2].Id}),"trusted server-only refused");Fails(()=>c.Unlock(new[]{defs[3].Id}),"unknown permission flag refused");Check(f.Sets==0,"protected batch has no partial writes");}
                {var f=new FakeStats();var c=Ready(f);f.Context=false;Fails(()=>c.Unlock(new[]{"FIXTURE_ONLY_0"}),"account/context switch refused");Check(f.Sets==0,"context change makes zero writes");}
                {var f=new FakeStats();var c=Ready(f,Defs().Take(48).ToList());Check(c.State==Phase.Error&&c.RequiresRestart,"wrong schema cardinality locks writes");}
                {var f=new FakeStats{ReadOK=false};var c=Ready(f);Check(c.State==Phase.Error,"incomplete getters lock writes");}
                {var f=new FakeStats();var c=Ready(f,null,o=>{throw new IOException("snapshot disk full");});Fails(()=>c.Unlock(new[]{"FIXTURE_ONLY_0"}),"failed before-state snapshot blocks write");Check(f.Sets==0,"snapshot failure zero writes");}
                {var f=new FakeStats();int snap=0;var c=Ready(f,null,o=>{snap++;});c.Unlock(new[]{"FIXTURE_ONLY_0","FIXTURE_ONLY_1"});Check(snap==1&&f.Sets==2&&f.Stores==1,"explicit selected batch stored once");Check(c.State==Phase.Writing,"Set/Store bool not treated as success");Fails(()=>c.Unlock(new[]{"FIXTURE_ONLY_2"}),"double submit while waiting refused");f.Complete();Check(c.State==Phase.Verifying&&f.Requests==2,"successful callback initiates fresh readback");f.Receive();Check(c.State==Phase.Ready&&c.Outcome=="CALLBACK_OK_CLIENT_READBACK_OK","callback plus client readback recorded");Check(c.Rows[0].Unlocked,"new state reflected only after readback");}
                {var f=new FakeStats();var c=Ready(f);c.Unlock(new[]{"FIXTURE_ONLY_0"});f.Complete(2);Check(c.State==Phase.Error&&c.Outcome=="STORE_CALLBACK_FAILED","failed Store callback not green");Check(c.RequiresRestart,"uncertain operation prevents retries");}
                {var f=new FakeStats{StoreOK=false};var c=Ready(f);c.Unlock(new[]{"FIXTURE_ONLY_0"});Check(c.Outcome=="STORE_REJECTED_UNCERTAIN","Store false reported uncertain");}
                {var f=new FakeStats();var c=Ready(f);c.Unlock(new[]{"FIXTURE_ONLY_0"});f.Complete();f.Values["FIXTURE_ONLY_0"]=false;f.Receive();Check(c.Outcome=="CALLBACK_OK_READBACK_MISMATCH","readback mismatch not called fully unlocked");}
                {var now=DateTime.UtcNow;var f=new FakeStats();var c=Ready(f,null,null,()=>now);c.Unlock(new[]{"FIXTURE_ONLY_0"});now=now.AddSeconds(46);c.Tick();Check(c.Outcome=="TIMEOUT_UNCERTAIN"&&c.RequiresRestart,"timeout fails closed");Fails(()=>c.Refresh(),"timeout requires process reopen");f.Complete();Check(c.State==Phase.Error,"late callback cannot certify timed-out request");}
                {var f=new FakeStats();f.Reject.Add("FIXTURE_ONLY_0");var c=Ready(f);c.Unlock(new[]{"FIXTURE_ONLY_0","FIXTURE_ONLY_1"});Check(c.Submitted.Count==1&&c.Rejected.Count==1,"partial native rejection tracked per item");f.Complete();f.Receive();Check(c.Rows[0].Unlocked==false&&c.Rows[1].Unlocked,"rejected entry not reported unlocked");}
                {var f=new FakeStats();var defs=Defs();defs[48].Id=defs[0].Id;var c=Ready(f,defs);Check(c.State==Phase.Error,"duplicate schema IDs lock writes");}
                {var f=new FakeStats();var defs=Defs();defs[0].Id="Injected\0Name";var c=Ready(f,defs);Check(c.State==Phase.Error,"invalid native API string refused");}
                // Schema parser: old numeric and current named types, permission inheritance.
                var bit=Node("0",S("name","FIXTURE_ONLY_SCHEMA"),Node("display",Node("name",S("english","Hackification")),Node("desc",S("english","Fixture description"))));
                var kv=Node("root",Node("243470",Node("stats",Node("group",S("type","Achievements"),I("permission",1),Node("bits",bit)))));
                var parsed=SteamBackend.Parse(kv);Check(parsed.Count==1&&parsed[0].Id=="FIXTURE_ONLY_SCHEMA","schema API identifier read from name field");Check(parsed[0].EnglishName=="Hackification","localized English title extracted");Check(parsed[0].Permission==1,"group protection inherited");
                var old=Node("root",Node("243470",Node("stats",Node("group",I("type",4),Node("bits",bit)))));Check(SteamBackend.Parse(old).Count==1,"legacy integer schema type supported");
                var unknown=Node("root",Node("243470",Node("stats",Node("group",I("type",4),S("permission","unknown"),Node("bits",bit)))));Check(SteamBackend.Parse(unknown)[0].Permission!=0,"unparseable permission fails protected");
                Check(new StoredCallback().Id==1102,"official stored callback ID");
                var assembly=System.Reflection.Assembly.LoadFile(Path.Combine(project,"WD1-Toolkit.exe"));var install=assembly.GetType("WD1Kit.LocalStorage").GetMethod("Install");var il=install.GetMethodBody().GetILAsByteArray();bool hasGuard=false;for(int i=0;i<il.Length-4;i++)if(il[i]==0x28)try{var method=install.Module.ResolveMethod(BitConverter.ToInt32(il,i+1));if(method.Name=="Require"&&method.DeclaringType.FullName=="WD1Kit.Identity")hasGuard=true;}catch{}Check(hasGuard,"actual release EXE includes identity gate (no fixture bypass)");
                Console.WriteLine("CSHARP_FIXTURE_CHECKS="+count);return 0;
            }catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
            finally{if(Directory.Exists(root))Directory.Delete(root,true);}
        }
    }
}
