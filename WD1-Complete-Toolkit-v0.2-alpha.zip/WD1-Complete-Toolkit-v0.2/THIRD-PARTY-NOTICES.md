# 第三方组件与署名

## 本项目原创部分

`src/Companion`、`src/Plugin`、`src/Steam`、`src/Shared` 以及原创构建/测试逻辑采用根目录 `LICENSE.txt` 的 MIT 许可。实现不等于已获游戏兼容性认证；无 Ubisoft、Valve、Troplo 或 gibbed 背书。

## Steam Achievement Manager / SAM.API

- 作者：**Rick / gibbed**。
- 上游：https://github.com/gibbed/SteamAchievementManager
- 固定提交：`de8b71048a0cee3c3e97cd8535e0f55ca86513e4`。
- 许可：**zlib**，见 `third_party/SAM.API/LICENSE.txt` 与 `third_party/SAM.Schema/LICENSE.txt`；每份源码的原始版权头保留。
- 随包内容：`SAM.API` 的 C# 源文件，以及 `SAM.Game` 下 `KeyValue.cs`、`KeyValueType.cs`、`StreamHelpers.cs` 的解析器源文件。
- **这些第三方源码文件未作内容修改。** 本项目用自己的构建过程将 API 编译成重新命名的 `WD1.SteamBridge.dll`，并将 schema 解析器链接进原创 `WD1-Achievements.exe`。生成程序集不是上游官方发布的 SAM 二进制。
- WD1 专用界面、49 项/权限/会话门槛、before-state 记录、1102 回调适配与结果工作流由本项目编写。没有复制 SAM.Picker / SAM.Game 的整体界面、图标或联网图标下载流程。
- 第三方通用 API 库中存在本工具未调用的通用方法；本工具用户界面不提供重置统计、清空或回锁成就。

## NexusTools / Troplo

- 作者宿主：https://www.nexusmods.com/watchdogs/mods/491
- 文档：https://www.kaverti.com/en/TroploNexusTools/Home
- Trainer 接口参考：https://github.com/Troplo/NexusTools.Trainer ，提交 `a20b61be0e2e00258ccb10ccfeb1be78c9b60450`。
- Assets 格式参考：https://github.com/Troplo/NexusTools.Assets ，观察提交 `64c63e87430ce4cffde615b203032cd203ad3dde`。
- **没有捆绑或重新发布 NexusTools 核心 ASI、代理 DLL、安装器或完整自带 Trainer。** 原创插件需要用户按作者说明另行安装宿主。
- `data/runtime_items.*` 是精选键/名称/类别等互操作事实，保留来源字段；不是上游整张数据库或游戏资源的复制。`src/Plugin` 中控制、安全、菜单逻辑由本项目编写。
- 不将作者允许修改训练器脚本解释成对宿主核心任意分发的授权。

## Steam / Ubisoft / Watch_Dogs

商标和游戏内容属于各自权利方。本包不包含 Steam `steamclient.dll`、`steam_api*.dll`、Ubisoft loader、Watch_Dogs 引擎/EXE、游戏资源、账号文件或用户存档。Steam 成就工具在用户主动读取/确认后使用其已登录的本机 Steam 客户端；不授予游戏或 DLC 所有权。

## 构建工具

开发使用 Roslyn 4.8、Mono、Lua 5.1、Python、Xvfb 等；它们没有作为用户运行依赖打包。Windows 程序依赖 .NET Framework 4.8 系列。没有通过混淆或封装隐藏第三方归属。
