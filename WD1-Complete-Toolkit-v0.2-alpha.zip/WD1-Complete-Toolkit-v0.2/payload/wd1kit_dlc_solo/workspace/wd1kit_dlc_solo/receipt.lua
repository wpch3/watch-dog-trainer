-- Unauthorised source template. The companion replaces this only after a verified backup.
return {format=1,product="WD1KIT",mode="dlc_solo",allow_persistent=false}
