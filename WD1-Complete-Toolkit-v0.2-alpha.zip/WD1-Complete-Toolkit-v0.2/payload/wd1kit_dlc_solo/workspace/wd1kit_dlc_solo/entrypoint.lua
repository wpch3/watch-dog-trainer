-- Original WD1KIT entry point. No automatic cheats on load.
local mode = "dlc_solo"
local folder = "wd1kit_dlc_solo/"
if WD1KIT_ACTIVE and WD1KIT_ACTIVE.alive then
    if WD1KIT_ACTIVE.mode == mode then return end
    WD1KIT_ACTIVE:shutdown("MODE_SWITCH_REQUIRES_RESTART")
    if WD1KIT_ACTIVE.script then pcall(function() WD1KIT_ACTIVE.script:Remove() end) end
end
local create = dofile(folder .. "core.lua")
local catalog = dofile(folder .. "catalog.lua")
local receipt = dofile(folder .. "receipt.lua")
local c = create(_G, catalog, receipt, mode)
WD1KIT_ACTIVE = c
local ok = pcall(function() dofile(folder .. "menu.lua")(c, catalog, mode) end)
if not ok then c:shutdown("MENU_INIT_ERROR"); c:message("WD1KIT: incompatible host or menu error. No cheats enabled.") end
