-- Unauthorised source template. The companion replaces this only after a verified backup.
return {format=1,product="WD1KIT",mode="campaign",allow_persistent=false}
