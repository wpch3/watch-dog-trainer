// WD1-specific adapter around unmodified SAM.API (gibbed, zlib license).
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using SAM.Game;
using SAM.API.Types;
namespace WD1Kit.Steam {
    // Official Steam callback family ISteamUserStats: 1101 Received, 1102 Stored.
    public sealed class StoredCallback:SAM.API.Callback<UserStatsStored> {public override int Id {get{return 1102;}}public override bool IsServer {get{return false;}}}
    public sealed class SteamBackend:IStats {
        const uint AppId=243470;readonly SAM.API.Client client=new SAM.API.Client();ulong initialUser;bool disposed=false;
        public event Action<int> Received;public event Action<int> Stored;
        public SteamBackend(){
            try {
                if(Environment.Is64BitProcess)throw new InvalidOperationException("此 Steam 桥接必须作为随包的 x86 独立程序运行。");
                Files.GameClosed();client.Initialize(AppId);
                initialUser=client.SteamUser.GetSteamId();
                if(!ContextOK())throw new IOException("当前 Steam 账号没有返回有效的 WD1 订阅 / AppID 状态，拒绝连接。");
                var r=client.CreateAndRegisterCallback<SAM.API.Callbacks.UserStatsReceived>();
                r.OnRun+=p=>{if(p.GameId==AppId&&p.SteamIdUser==initialUser&&Received!=null)Received(p.Result);};
                var s=client.CreateAndRegisterCallback<StoredCallback>();
                s.OnRun+=p=>{if(p.GameId==AppId&&Stored!=null)Stored(p.Result);};
            }catch{client.Dispose();throw;}
        }
        public bool ContextOK(){return !disposed&&client.SteamUser!=null&&client.SteamUserStats!=null&&client.SteamUtils!=null&&client.SteamApps008!=null&&initialUser!=0&&client.SteamUser.GetSteamId()==initialUser&&client.SteamUtils.GetAppId()==AppId&&client.SteamApps008.IsSubscribedApp(AppId);}
        public bool Request(){return ContextOK()&&client.SteamUserStats.RequestUserStats(initialUser)!=SAM.API.CallHandle.Invalid;}
        public bool Get(string id,out bool value,out uint time){return client.SteamUserStats.GetAchievementAndUnlockTime(id,out value,out time);}
        public bool Set(string id){return ContextOK()&&client.SteamUserStats.SetAchievement(id,true);}
        public bool Store(){return ContextOK()&&client.SteamUserStats.StoreStats();}
        public void Pump(){if(!disposed)client.RunCallbacks(false);}
        public void Dispose(){if(!disposed){disposed=true;client.Dispose();}}
        public static List<Definition> Schema(){
            string root=SAM.API.Steam.GetInstallPath();if(string.IsNullOrWhiteSpace(root))throw new IOException("找不到 Steam 安装路径。");
            string path=Path.Combine(root,"appcache","stats","UserGameStatsSchema_243470.bin");
            if(!File.Exists(path))throw new IOException("Steam 尚未缓存 WD1 schema。请在 Steam 正常启动 WD1 一次并退出，再重开此工具；无需提供 API Key。");
            if(new FileInfo(path).Length>8*1024*1024)throw new IOException("Steam schema 大小异常。");
            return Parse(KeyValue.LoadAsBinary(path));
        }
        internal static List<Definition> Parse(KeyValue kv){
            if(kv==null)throw new IOException("无法解析 Steam schema。");
            var stats=kv["243470"]["stats"];if(!stats.Valid||stats.Children==null)throw new IOException("schema 不含 WD1 stats 节点。");
            var result=new List<Definition>();
            foreach(var stat in stats.Children){
                UserStatType type;var t=stat["type"];
                if(!t.Valid||t.Type!=KeyValueType.String||!Enum.TryParse(t.AsString(""),true,out type))type=UserStatType.Invalid;
                if(type==UserStatType.Invalid)type=(UserStatType)(stat["type_int"].Valid?stat["type_int"].AsInteger(0):t.AsInteger(0));
                if(type!=UserStatType.Achievements&&type!=UserStatType.GroupAchievements)continue;
                if(stat.Children==null)continue;
                foreach(var bits in stat.Children.Where(b=>string.Equals(b.Name,"bits",StringComparison.OrdinalIgnoreCase)&&b.Valid&&b.Children!=null))foreach(var bit in bits.Children){
                    string id=bit["name"].AsString("");var n=bit["display"]["name"];var d=bit["display"]["desc"];
                    result.Add(new Definition{Id=id,EnglishName=n["english"].AsString(n.AsString(id)),Description=d["english"].AsString(d.AsString("")),Permission=(bit["permission"].Valid?bit["permission"].AsInteger(int.MinValue):0)|(stat["permission"].Valid?stat["permission"].AsInteger(int.MinValue):0),Trusted=bit["bSetByTrustedGS"].AsBoolean(false)||stat["bSetByTrustedGS"].AsBoolean(false)});
                }
            }
            return result;
        }
    }
}
