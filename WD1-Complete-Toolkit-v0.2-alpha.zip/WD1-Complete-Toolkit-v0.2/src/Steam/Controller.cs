// Original WD1-only achievement workflow. MIT. No stat editing, resets or relocking.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
namespace WD1Kit.Steam {
    public class Definition {public string Id; public string EnglishName; public string Description; public int Permission; public bool Trusted;}
    public class Achievement:Definition {public bool Unlocked;public uint UnlockTime;public bool Readable;public bool Online;public bool Protected {get{return Permission!=0||Trusted;}}}
    public class Hint {public string Name;public string Description;public bool Online;}
    public interface IStats:IDisposable {
        event Action<int> Received; event Action<int> Stored;
        bool ContextOK(); bool Request(); bool Get(string id,out bool value,out uint time); bool Set(string id); bool Store(); void Pump();
    }
    public enum Phase {Idle,Reading,Ready,Writing,Verifying,Error}
    public sealed class Controller {
        public readonly IStats Backend; readonly Func<List<Definition>> schema; readonly Action<object> snapshot; readonly Func<DateTime> clock; readonly Hint[] hints;
        public List<Achievement> Rows=new List<Achievement>(); public List<string> Submitted=new List<string>(),Rejected=new List<string>();
        public Phase State=Phase.Idle; public bool RequiresRestart=false; public string Status="尚未读取：不会自动写入。";
        public string Outcome="NOT_ATTEMPTED"; public int CallbackResult=0; public int SchemaObservedCount=-1; DateTime deadline;
        public event Action Changed;
        public Controller(IStats b,Func<List<Definition>> load,Hint[] hints,Action<object> save,Func<DateTime> clock=null) {
            Backend=b;schema=load;this.hints=hints??new Hint[0];snapshot=save;this.clock=clock??(()=>DateTime.UtcNow);
            b.Received+=Received;b.Stored+=Stored;
        }
        void Notify(){if(Changed!=null)Changed();}
        void Fail(string text,bool restart=true){State=Phase.Error;RequiresRestart=restart;Status=text;Notify();}
        public void Refresh(){
            if(RequiresRestart||State==Phase.Writing||State==Phase.Verifying||State==Phase.Reading)throw new InvalidOperationException("当前请求尚未结束或结果不确定。请先关闭并重开本工具。");
            if(!Backend.ContextOK())throw new InvalidOperationException("Steam 当前账号 / AppID / 订阅状态不匹配，拒绝操作。");
            State=Phase.Reading;Status="正在请求 WD1 成就状态（最多等待 45 秒）…";deadline=clock().AddSeconds(45);Notify();
            if(!Backend.Request())Fail("Steam 拒绝读取请求；请关闭重开，不会写入。");
        }
        static string Normal(string s){return Regex.Replace((s??"").ToLowerInvariant(),@"[^a-z0-9]","");}
        void Received(int result){
            if(State!=Phase.Reading&&State!=Phase.Verifying)return;
            bool verifying=State==Phase.Verifying;
            if(result!=1){Fail("Steam 读取回调失败，EResult="+result+"。未确认任何新解锁。");return;}
            try {
                if(!Backend.ContextOK())throw new IOException("Steam 会话发生变化。");
                var defs=schema();SchemaObservedCount=defs==null?0:defs.Count;
                if(defs==null||defs.Count!=49||defs.Any(d=>!Regex.IsMatch(d.Id??"",@"^[A-Za-z0-9_.:-]{1,128}$"))||defs.Select(d=>d.Id).Distinct(StringComparer.Ordinal).Count()!=49)throw new IOException("实际 schema 不是预期的 49 项、存在重复或名称非法；保持只读，需核实。");
                var rows=new List<Achievement>();
                foreach(var d in defs){bool value;uint time;bool ok=Backend.Get(d.Id,out value,out time);
                    var hint=hints.FirstOrDefault(h=>Normal(h.Name)==Normal(d.EnglishName));
                    rows.Add(new Achievement{Id=d.Id,EnglishName=d.EnglishName,Description=hint==null?d.Description:hint.Description,Permission=d.Permission,Trusted=d.Trusted,Unlocked=value,UnlockTime=time,Readable=ok,Online=hint!=null&&hint.Online});}
                Rows=rows;
                if(rows.Any(r=>!r.Readable))throw new IOException("部分成就无法回读，所有写入暂时锁定。");
                State=Phase.Ready;
                if(verifying){int count=Submitted.Count(id=>Rows.Any(r=>r.Id==id&&r.Unlocked));Outcome=count==Submitted.Count?"CALLBACK_OK_CLIENT_READBACK_OK":"CALLBACK_OK_READBACK_MISMATCH";
                    Status="Steam 写入回调成功；客户端回读 "+count+" / "+Submitted.Count+" 项为已解锁。拒绝 "+Rejected.Count+" 项。请关闭重开再核验；游戏进度不会随之改变。";}
                else Status="已读取真实 schema / 状态：49 项，已解锁 "+Rows.Count(r=>r.Unlocked)+"，受保护 "+Rows.Count(r=>r.Protected)+"。此次读取未改写状态。";
                Notify();
            } catch(Exception ex){Fail(ex.Message);}
        }
        public List<Achievement> ValidateSelection(IEnumerable<string> ids){
            if(State!=Phase.Ready||RequiresRestart||Rows.Count!=49||Rows.Any(r=>!r.Readable)||!Backend.ContextOK())throw new InvalidOperationException("状态未完整读取或会话失效。拒绝写入。");
            var input=ids.ToList();if(input.Count<1||input.Count>49||input.Distinct(StringComparer.Ordinal).Count()!=input.Count)throw new InvalidOperationException("选择为空、重复或过多。");
            var selected=new List<Achievement>();foreach(string id in input){var r=Rows.SingleOrDefault(x=>x.Id==id);if(r==null||r.Protected)throw new InvalidOperationException("未知 / 受保护 / 服务器设置成就，拒绝整个批次。");if(!r.Unlocked)selected.Add(r);}
            if(selected.Count==0)throw new InvalidOperationException("所选项目已经解锁，无需再次写入。");return selected;
        }
        public void Unlock(IEnumerable<string> ids){
            Files.GameClosed();var selected=ValidateSelection(ids);
            // A local before-state record is not a reversible platform backup.
            snapshot(new {Product="WD1KIT",Format=1,AppId=243470,Utc=clock().ToString("o"),Warning="Not a rollback mechanism; no account identifiers stored",Before=Rows.Select(r=>new{r.Id,r.EnglishName,r.Unlocked,r.UnlockTime,r.Permission,r.Trusted}).ToArray(),Requested=selected.Select(r=>r.Id).ToArray()});
            Files.GameClosed();if(!Backend.ContextOK())throw new IOException("提交前 Steam 会话已改变。");
            Submitted.Clear();Rejected.Clear();CallbackResult=0;Outcome="SET_ATTEMPTED";
            State=Phase.Writing;deadline=clock().AddSeconds(45);Status="正在提交所选 WD1 成就，等待 Steam 回调…";Notify();
            try {
                foreach(var r in selected){if(Backend.Set(r.Id))Submitted.Add(r.Id);else Rejected.Add(r.Id);}
                if(Submitted.Count==0){Outcome="ALL_SET_REJECTED";Fail("Steam 拒绝全部 SetAchievement 请求，没有成功解锁证明。");return;}
                Outcome="STORE_SENT_WAITING_CALLBACK";
                if(!Backend.Store()){Outcome="STORE_REJECTED_UNCERTAIN";Fail("StoreStats 被拒绝。本地缓存可能已改变；不要重试或自动回退，请关闭重开核对。");return;}
            }catch(Exception ex){Outcome="EXCEPTION_UNCERTAIN";Fail("提交异常："+ex.GetType().Name+"。结果不确定，请关闭重开核对。");}
        }
        void Stored(int result){
            if(State!=Phase.Writing)return;CallbackResult=result;
            if(result!=1){Outcome="STORE_CALLBACK_FAILED";Fail("Steam 写入回调失败，EResult="+result+"；不把 SetAchievement 返回值当成已解锁。");return;}
            if(!Backend.ContextOK()){Outcome="CALLBACK_OK_CONTEXT_CHANGED";Fail("收到成功回调，但会话已变化，无法回读。");return;}
            State=Phase.Verifying;Status="Steam 已返回写入成功，正在重新请求并回读状态…";deadline=clock().AddSeconds(45);Notify();
            if(!Backend.Request()){Outcome="CALLBACK_OK_READBACK_REFUSED";Fail("收到成功写入回调，但回读请求失败，请关闭重开核对。");}
        }
        public void Tick(){
            try{Backend.Pump();}catch(Exception ex){Outcome="CALLBACK_PUMP_ERROR";Fail("Steam 回调异常："+ex.GetType().Name+"。请关闭重开。");return;}
            if((State==Phase.Reading||State==Phase.Writing||State==Phase.Verifying)&&clock()>deadline){Outcome="TIMEOUT_UNCERTAIN";Fail("45 秒内未收到匹配回调。不能声称完成；请关闭重开核对，不要重复提交。");}
        }
    }
}
