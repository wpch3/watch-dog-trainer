using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
[assembly:System.Reflection.AssemblyTitle("WD1 Steam 成就工具")]
[assembly:System.Reflection.AssemblyVersion("0.2.0.0")]
[assembly:System.Reflection.AssemblyFileVersion("0.2.0.0")]
namespace WD1Kit.Steam {
    static class Program {
        [STAThread] static void Main(string[] args){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);try{Application.Run(new SteamForm(args.Contains("--ui-smoke")));}catch(Exception ex){MessageBox.Show(ex.Message,"WD1 Steam 成就工具",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
    }
    class SteamForm:Form {
        Controller controller; SteamBackend backend;Timer timer;readonly bool smoke;bool updating=false;
        ListView list=new ListView {Dock=DockStyle.Fill,View=View.Details,FullRowSelect=true,CheckBoxes=true,HideSelection=false,BackColor=Theme.Card,ForeColor=Theme.Text,BorderStyle=BorderStyle.None};
        Label status=Theme.Label("未连接 Steam。请关闭 WD1，登录拥有该游戏的 Steam 账号。不会在启动时解锁。");
        Button write,refresh;string dataRoot;string lastErrorType="NONE",lastInitFailure="NONE";
        public SteamForm(bool smoke){
            this.smoke=smoke;Theme.Form(this,"WD1 Steam 成就工具 · 仅 AppID 243470 · 0.2 alpha");
            dataRoot=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WD1CompleteToolkit","steam");
            var top=Theme.Flow(true);top.Controls.Add(Theme.Label("不再依赖匹配玩家，但平台成就 ≠ 游戏内完成度",true));
            top.Controls.Add(Theme.Label("只解锁你勾选、未完成且客户端可写的成就。不改 Ubisoft 记录 / 对局次数 / 单机物品。操作可能永久保留；本工具不提供回锁、清空或统计重置。"));
            top.Controls.Add(Theme.Label("底层：gibbed / SAM.API（zlib）。使用已登录的本机 Steam，不索取密码、API Key 或登录令牌。游戏与其他联机游戏请先关闭。"));
            var buttons=Theme.Flow();
            refresh=Theme.Button("读取 / 刷新真实状态",(s,e)=>Run(()=>{Connect();controller.Refresh();}));buttons.Controls.Add(refresh);
            buttons.Controls.Add(Theme.Button("选择线上相关 6 项",(s,e)=>Select(true)));
            buttons.Controls.Add(Theme.Button("选择全部未解锁可写项",(s,e)=>Select(false)));
            buttons.Controls.Add(Theme.Button("清除本次勾选",(s,e)=>{foreach(ListViewItem item in list.Items)item.Checked=false;}));
            top.Controls.Add(buttons);
            var row=Theme.Flow();write=Theme.Button("解锁所选 → 先确认",(s,e)=>Unlock(),true);write.Enabled=false;row.Controls.Add(write);
            row.Controls.Add(Theme.Button("导出脱敏状态 / 反馈",(s,e)=>Export()));top.Controls.Add(row);top.Controls.Add(status);
            list.Columns.Add("名称 / 原始条件",255);list.Columns.Add("状态",85);list.Columns.Add("写入权限",95);list.Columns.Add("线上相关",85);list.Columns.Add("实际 Steam API 名",260);list.Columns.Add("解锁时间（UTC）",170);
            list.ItemCheck+=(s,e)=>{if(updating)return;var a=list.Items[e.Index].Tag as Achievement;if(a==null||a.Protected||a.Unlocked||!a.Readable)e.NewValue=e.CurrentValue;};
            list.DoubleClick+=(s,e)=>{if(list.SelectedItems.Count==1){var a=list.SelectedItems[0].Tag as Achievement;if(a!=null)MessageBox.Show(a.EnglishName+"\n\n"+a.Description+"\n\nAPI: "+a.Id+"\npermission="+a.Permission+"; trustedGS="+a.Trusted,"实际 schema 条目");}};
            Controls.Add(list);Controls.Add(top);Controls.Add(Theme.Header("STEAM ACHIEVEMENTS   /   默认只读   /   回调确认 + 客户端回读   /   本机实测待完成"));
            FormClosing+=(s,e)=>{if(controller!=null&&(controller.State==Phase.Writing||controller.State==Phase.Verifying)){if(MessageBox.Show("Steam 请求尚未结束。关闭后结果可能不确定；不要马上重试。仍要关闭？","等待中的操作",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)e.Cancel=true;}};
            FormClosed+=(s,e)=>{if(timer!=null)timer.Stop();if(backend!=null)backend.Dispose();};
            if(smoke)Shown+=(s,e)=>{status.Text="UI SMOKE / 没有 Steam 连接，没有加载账号或成就数据。";var t=new Timer{Interval=900};t.Tick+=(a,b)=>{t.Stop();using(var bmp=new Bitmap(Width,Height)){using(var gr=Graphics.FromImage(bmp)) gr.CopyFromScreen(Location,Point.Empty,Size);bmp.Save(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ui-steam.png"));}Close();};t.Start();};
        }
        void Run(Action a){try{a();}catch(Exception ex){lastErrorType=ex.GetType().Name;var init=ex as SAM.API.ClientInitializeException;if(init!=null)lastInitFailure=init.Failure.ToString();status.Text="操作停止："+ex.Message;MessageBox.Show(this,ex.Message,"未执行 / 未完成",MessageBoxButtons.OK,MessageBoxIcon.Warning);}}
        void Connect(){if(smoke)throw new InvalidOperationException("UI smoke 模式不连接 Steam。");if(controller!=null)return;Files.GameClosed();
            backend=new SteamBackend(); Hint[] hints;
            try{hints=Files.Read<Hint[]>(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"data","achievement_hints.json"));}catch{hints=new Hint[0];}
            controller=new Controller(backend,SteamBackend.Schema,hints,obj=>{Directory.CreateDirectory(dataRoot);Files.Write(Path.Combine(dataRoot,"before-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8)+".json"),obj);});
            controller.Changed+=UpdateView;timer=new Timer{Interval=150};timer.Tick+=(s,e)=>{controller.Tick();if(controller.RequiresRestart)timer.Stop();};timer.Start();
        }
        void UpdateView(){
            var selected=list.Items.Cast<ListViewItem>().Where(i=>i.Checked).Select(i=>((Achievement)i.Tag).Id).ToHashSetCompat();
            updating=true;list.BeginUpdate();list.Items.Clear();
            foreach(var a in controller.Rows){string time=a.UnlockTime==0?"—":new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddSeconds(a.UnlockTime).ToString("yyyy-MM-dd HH:mm:ss");
                var item=new ListViewItem(a.EnglishName??a.Id){Tag=a,Checked=selected.Contains(a.Id)&&!a.Unlocked&&!a.Protected,ForeColor=a.Protected?Color.Salmon:a.Unlocked?Theme.Accent:Theme.Text};
                item.SubItems.Add(a.Unlocked?"已解锁":"未解锁");item.SubItems.Add(a.Protected?"受保护 / 禁写":"客户端候选");item.SubItems.Add(a.Online?"是":"否 / 未映射");item.SubItems.Add(a.Id);item.SubItems.Add(time);list.Items.Add(item);}
            list.EndUpdate();updating=false;status.Text=controller.Status;
            bool ready=controller.State==Phase.Ready&&!controller.RequiresRestart;write.Enabled=ready;refresh.Enabled=controller.State!=Phase.Reading&&controller.State!=Phase.Writing&&controller.State!=Phase.Verifying&&!controller.RequiresRestart;
        }
        void Select(bool online){Run(()=>{if(controller==null||controller.State!=Phase.Ready)throw new IOException("请先完整读取实际 Steam schema 和状态。");int n=0;
            foreach(ListViewItem item in list.Items){var a=(Achievement)item.Tag;bool pick=!a.Unlocked&&!a.Protected&&a.Readable&&(!online||a.Online);item.Checked=pick;if(pick)n++;}
            status.Text="本次仅勾选了 "+n+" 项，尚未写入。"+(online?"六项名称中已解锁 / 受保护 / 未匹配的项目不会强行勾选。":"");});}
        void Unlock(){Run(()=>{
            if(controller==null)throw new IOException("请先读取。");var ids=list.Items.Cast<ListViewItem>().Where(i=>i.Checked).Select(i=>((Achievement)i.Tag).Id).ToList();
            var selected=controller.ValidateSelection(ids);
            string names=string.Join("\n",selected.Take(12).Select(a=>"• "+a.EnglishName))+(selected.Count>12?"\n… 共 "+selected.Count+" 项":"");
            if(MessageBox.Show(this,"将向 Steam 请求解锁以下 "+selected.Count+" 项：\n\n"+names+"\n\n这不是解锁游戏物品，也不会补写 Ubisoft / 在线合约记录。\n平台操作可能永久保留；不能靠还原游戏存档撤销。\n确认现在提交？","明确确认后才写入",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            controller.Unlock(ids);
        });}
        void Export(){Run(()=>{using(var d=new SaveFileDialog{Filter="JSON 报告|*.json",FileName="WD1-Steam-Feedback.json"})if(d.ShowDialog(this)==DialogResult.OK){
            string steam=SAM.API.Steam.GetInstallPath();if((!string.IsNullOrWhiteSpace(steam)&&Files.Under(d.FileName,steam))||Files.Under(d.FileName,dataRoot))throw new IOException("报告请另存桌面 / 下载目录，不能写进 Steam 或工具内部快照目录。");
            Files.Write(d.FileName,new{product="WD1KIT",version="0.2.0-alpha",appid=243470,utc=DateTime.UtcNow.ToString("o"),state=controller==null?"NOT_CONNECTED":controller.State.ToString(),outcome=controller==null?"NOT_ATTEMPTED":controller.Outcome,error_type=lastErrorType,initialize_failure=lastInitFailure,observed_schema_count=controller==null?-1:controller.SchemaObservedCount,store_callback_result=controller==null?0:controller.CallbackResult,submitted=controller==null?new string[0]:controller.Submitted.ToArray(),rejected=controller==null?new string[0]:controller.Rejected.ToArray(),achievements=(controller==null?new List<Achievement>():controller.Rows).Select(r=>new{api_name=r.Id,name=r.EnglishName,unlocked=r.Unlocked,unlock_time=r.UnlockTime,permission=r.Permission,trustedGS=r.Trusted,readable=r.Readable,online_reference=r.Online}).ToArray()});
            status.Text="已导出：只有 WD1 成就名 / 状态 / 权限 / 操作结果；没有账号 ID、路径、存档或令牌。未上传。";
        }});}
    }
    static class EnumerableCompat {public static HashSet<T> ToHashSetCompat<T>(this IEnumerable<T> source){return new HashSet<T>(source);}}
}
