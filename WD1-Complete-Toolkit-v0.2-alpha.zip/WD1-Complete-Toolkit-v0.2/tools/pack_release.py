#!/usr/bin/env python3
"""Package only public release files; do not include private reports or scratch executables."""
from pathlib import Path
import hashlib,zipfile
R=Path(__file__).resolve().parents[1]
SKIP={'ui-companion.png','ui-steam.png','release-tests/Test-Core.exe','SHA256SUMS.txt'}
EXCLUDED={'__pycache__','.cache','.git','reports','backups','private-saves','node_modules','dist','build'}
allowed_bins={'WD1-Toolkit.exe','WD1-Achievements.exe','WD1.SteamBridge.dll'}
files=[]
for f in sorted(R.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(R).as_posix()
 if rel in SKIP or any(p in EXCLUDED for p in f.relative_to(R).parts):continue
 if f.suffix.lower() in {'.exe','.dll','.asi','.pdb','.dmp','.save','.sav'}:
  if rel not in allowed_bins:raise RuntimeError('Unexpected binary/private file: '+rel)
 if f.name in {'Watch_Dogs.exe','Disrupt_b64.dll','uplay_r1_loader64.dll','steamclient.dll','steam_api64.dll','WD1-Report.json.txt'}:raise RuntimeError('Game/user content is not distributable: '+rel)
 files.append(f)
sums=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(R).as_posix()+'\n' for f in files)
(R/'SHA256SUMS.txt').write_text(sums,encoding='utf8');files.append(R/'SHA256SUMS.txt')
archive=R.parent/'WD1-Complete-Toolkit-v0.2-alpha.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,'WD1-Complete-Toolkit-v0.2/'+f.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for f in files:
  assert z.read('WD1-Complete-Toolkit-v0.2/'+f.relative_to(R).as_posix())==f.read_bytes()
print('Archive:',archive.name)
print('Entries:',len(files))
print('Bytes:',archive.stat().st_size)
print('SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
