#!/usr/bin/env python3
"""Update release documentation/catalog state. No game or network access."""
from pathlib import Path
import json,csv,collections
R=Path(__file__).resolve().parents[1]
families=['god_mode','ammo_replenishment','focus_replenishment','felony_system_toggle','felony_heat_set','cash_grant','skillpoint_item_reward','xp_item_rewards','curated_item_rewards','bounded_vehicle_spawn','time_of_day_request']
profile={'source':'user diagnostic report, plus user statements; not a compatibility certificate','steam_appid':243470,'steam_build_id':'11241563','compatibility':'NOT_RUNTIME_VERIFIED','binary_sha256':{'bin/Watch_Dogs.exe':'844E4A85FD1D1AFE61BE2B75F451FA4A1BE91C83732731CC5ED2C36FF551E0CD','bin/Disrupt_b64.dll':'A4EEAD7A645AB4340A67622DA4BFC91789E8CECFD53F605499A0E4B09B3EE60A','bin/uplay_r1_loader64.dll':'4325FFDE93C453F68E5B13CFD225D90359FCF73331C65F23894128CEA6DCD116'},'user_confirmed_dlc':['dlc_exclusive','dlc_pill_people','dlc_seasonpass','dlc_solo','ulc_pack'],'bad_blood_starts':'user_confirmed','online_progress':'all_unfinished_user_statement','diagnostic_save_candidates':0,'progression_counters_in_report':False}
(R/'profiles/steam-11241563-observed.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2)+'\n')
p={'name':'WD1 Complete Toolkit','version':'0.2.0-alpha','as_of':'2026-09-13','stage':'implemented_test_build_pending_game_validation','is_finished_trainer':False,'steam_appid':243470,'game_write_features_implemented':len(families),'counting_note':'11 action families, not 212 verified cheats. 212 curated reward keys share the item mechanism. No game-runtime-verified feature.','implemented_game_action_families':families,'curated_item_keys':212,'game_runtime_verified_features':0,'confirmed_user_environment':{'os':'Windows 11 Pro 24H2 / 26100 x64','edition':'Steam Complete Edition','initial_mods':'vanilla, user statement','installation_preference':'Chinese desktop companion plus original in-game plugin','bad_blood':'starts, user statement','dlc':profile['user_confirmed_dlc']},'default_intent':'Preserve story by not editing mission/progression flags. Keep local inventory, progress, Steam and Ubisoft/server records separate.','implemented_deliverables':['compiled x64 .NET Framework companion','compiled x86 WD1-only Steam achievement tool','compiled x86 SAM.API bridge, attributed zlib source included','two original guarded Lua mode payloads','verified-copy save backup/restore and plugin-install rollback','read-only legacy collector','150 requirements with separate delivery status','49 achievement reference entries; actual API names queried only on user machine','212 curated original-item/reward facts'],'runtime_validation':'NO_REAL_GAME_OR_STEAM_RUNTIME_TEST','supported_game_fingerprints':[],'observed_target_profile':'profiles/steam-11241563-observed.json','fingerprint_gate':'Companion install and launch only; Lua has no independent per-start file hashing. Unknown hashes rejected by companion.','candidate_third_party_host':{'name':'NexusTools','minimum_version':'1.1.12','bundled':False,'compatibility_verified':False,'host_version_detection':'user confirmation, not automatic certification','source':'https://www.nexusmods.com/watchdogs/mods/491'},'steam_module':{'appid_fixed':243470,'schema_count_gate':49,'backend':'SAM.API / gibbed','upstream_commit':'de8b71048a0cee3c3e97cd8535e0f55ca86513e4','native_library_bundled':False,'read_before_write':True,'protected_achievements_refused':True,'runtime_verified':False,'real_api_names_known_to_developer':False},'tests':{'lua_fixture_checks_passed':126,'csharp_fixture_checks_passed':86,'desktop_smoke':'2 windows under Linux Mono/Xvfb, no Steam connection','collector_historical_ps7_checks':39,'collector_user_windows_report_received':True},'next_user_inputs':['Use the local picker to select and back up the actual save folder; no upload required','Optional reviewed WD1Kit-Feedback.json from first plugin test','Optional reviewed WD1-Steam-Feedback.json from live Steam read/test'],'do_not_request':['screenshots already declined','passwords','2FA codes','activation keys','Steam Web API keys','launcher login files','full memory dumps','full game or save uploads']}
(R/'project.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
# Keep old evidence classes as research provenance; delivery status is separate.
a=json.loads((R/'data/achievements.json').read_text())
a['runtime_note']='Reference only. Actual account state/API IDs are not bundled. v0.2 has a dynamic-schema, permission-gated Steam workflow; live compatibility remains unverified.'
for item in a['items']:
 item['implementation_status']='dynamic_client_workflow_implemented_runtime_unverified'
 item['note']='参考条目，不是账号状态。实际 API 名需工具从本机 Steam schema 读取；受保护项拒绝写入，实测待完成。'
(R/'data/achievements.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def csvwrite(name,rows):
 with (R/'data'/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvwrite('achievements.csv',a['items'])
f=json.loads((R/'data/feature_requirements.json').read_text())
f['warning']='150 requirements, not working cheats. evidence_class is original research provenance; delivery_v02/status describe current implementation. No game behavior is runtime verified.'
notes={
1:('READ_ONLY_USER_RUN','旧检测器已有 Windows PS5.1 用户报告；新桌面检测仅模拟测试。'),
2:('PARTIAL_UNVERIFIED','用户报告没有找到存档；新工具支持候选扫描和手动选择，不认定活动存档。'),
3:('PARTIAL_UNVERIFIED','桌面安装/启动前校验三项哈希；Lua 不独立重算二进制，直接从 Steam 启动仍须手动重验。'),
4:('PARTIAL_UNVERIFIED','实现 .save/.save.*/.sav 备份及哈希/变动检查；未知格式未支持，尚无用户真实备份。'),
5:('PARTIAL_UNVERIFIED','实现复制恢复、前置快照和异常回滚；通过模拟测试，恢复后能否进游戏待测。'),
7:('IMPLEMENTED_UNVERIFIED','恢复前要求退出 Ubisoft；提示人工处理云同步，不自动覆盖平台版本。'),
8:('PARTIAL_UNVERIFIED','物品/现金先预览再确认；未回读游戏原值、前置和拥有数量。'),
9:('IMPLEMENTED_UNVERIFIED','STOP 取消队列/关闭持续效果；已发奖励不回退。'),
10:('PARTIAL_UNVERIFIED','接入宿主 OnPause/OnResume 与实体变化保护；无真实会话状态回读，仍依赖手动单机确认。'),
11:('PARTIAL_UNVERIFIED','中文桌面/插件菜单和宿主命令注册已做；热键配置依赖宿主，实机待测。'),
12:('IMPLEMENTED_UNVERIFIED','实现受限格式插件日志提取与脱敏导出。'),
13:('IMPLEMENTED_UNVERIFIED','只处理自身标记目录，先归档；原版 EXE/DLL/dat/fat 不覆盖，文件模拟测试通过。'),
14:('IMPLEMENTED_UNVERIFIED','ActivateInvincibility/RemoveInvincibility；伤害场景实测待完成。'),
21:('IMPLEMENTED_UNVERIFIED','条件式 RefillAdrenaline 循环；修正了上游示例无条件补充的行为。'),
25:('IMPLEMENTED_UNVERIFIED','ModifyBulletsInClip 槽位 0–5 的补给循环；游戏效果待测。'),
26:('PARTIAL_UNVERIFIED','通过弹匣补给机制测试，未独立修改换弹动画/逻辑。'),
30:('PARTIAL_UNVERIFIED','支持 37 常规/特殊、3 ULC、8 BB 武器候选；无任意 NPC/MOD 授予。'),
31:('PARTIAL_UNVERIFIED','白名单批次已接入；不声称覆盖所有可玩武器或已永久解锁。'),
34:('PARTIAL_UNVERIFIED','支持白名单材料奖励；没有任意设值和当前数量回读。'),
37:('IMPLEMENTED_UNVERIFIED','GiveCash(0, amount)，每次 1–1000000，先备份与确认。'),
39:('PARTIAL_UNVERIFIED','4 个 XP 奖励物品键；不是任意经验值编辑/回读。'),
42:('PARTIAL_UNVERIFIED','Skillpoint 奖励键 +1–100；不是直接设值、无限锁定或技能树解锁。'),
51:('IMPLEMENTED_UNVERIFIED','请求热度 0；警察行为和任务状态待实测。'),
52:('IMPLEMENTED_UNVERIFIED','暂停通缉系统，STOP 恢复；不保留其他修改器设置。'),
53:('IMPLEMENTED_UNVERIFIED','FelonySetHeat(player, heat)；输入 0–100。'),
56:('PARTIAL_UNVERIFIED','6 车型、会话最多 5 辆；不自动入座、不广泛删实体。'),
57:('PARTIAL_UNVERIFIED','54 本体奖励候选键，叫车列表和重启持久性待验证。'),
68:('IMPLEMENTED_UNVERIFIED','脚本时刻设置；无已验证的自然时钟恢复 API，需重启。'),
75:('PARTIAL_UNVERIFIED','50 艾登、11 T-Bone 商店服装候选；持久性未验证。'),
77:('PARTIAL_UNVERIFIED','已有 Complete Edition 的部分 ULC 武器/服装候选，不授予内容所有权。'),
78:('PARTIAL_UNVERIFIED','部分特殊武器可请求；不推进其调查/支线状态。'),
80:('PARTIAL_UNVERIFIED','有四件线上武器批次，不写主线；没有完整存档差异/依赖分析。'),
92:('PARTIAL_UNVERIFIED','22 个歌曲奖励候选；第23键未定，SongSneak 计数未接入。'),
116:('IMPLEMENTED_UNVERIFIED','本体白名单 Items.770883049；需回读与重启验证。'),
117:('IMPLEMENTED_UNVERIFIED','本体白名单 Items.309961700；不是普通 Vector。'),
118:('IMPLEMENTED_UNVERIFIED','本体白名单 Items.2207476061；需回读与重启验证。'),
119:('IMPLEMENTED_UNVERIFIED','本体白名单 Items.4099987261；需回读与重启验证。'),
120:('PARTIAL_UNVERIFIED','Items.678076169 为叫车奖励映射候选；另有生成按钮，两者区分。'),
126:('PARTIAL_UNVERIFIED','独立 DLC manifest 和共享基础动作；T-Bone/Eugene 实机适配待完成。'),
137:('PARTIAL_UNVERIFIED','部分 BB 武器/服装；不含音频记录或调查计数。'),
140:('REFERENCE_COMPLETE','49 条官方名称/条件目录，不是账号解锁状态。'),
141:('IMPLEMENTED_UNVERIFIED','从真实 Steam schema 动态取名，RequestUserStats + 回调 + Getter；未连接真实客户端测试。'),
144:('IMPLEMENTED_UNVERIFIED','权限/账号/AppID/49项门槛，显式选中解锁、StoreStats 回调、客户端回读；不重置。'),
146:('IMPLEMENTED_UNVERIFIED','按 schema 英文名称映射六项，已解锁/受保护/未映射项不强选；不代表它们实际均可写。'),
147:('IMPLEMENTED_UNVERIFIED','界面明确提示平台不可由存档恢复撤销；仅保存 before-state 审计记录。')}
for item in f['items']:
 n=int(item['id'].split('-')[1]);state,note=notes.get(n,('NOT_IMPLEMENTED','本版未实现；保留需求，后续依据真实接口/测试继续适配。'))
 item['delivery_v02']=state;item['status']=note
(R/'data/feature_requirements.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n');csvwrite('feature_requirements.csv',f['items'])
doc='# 功能范围与逐项验收 · v0.2 Alpha\n\n150 项仍是总需求，不是“+150 已验证修改器”。`IMPLEMENTED_UNVERIFIED` 表示代码已写、尚无游戏实测；`PARTIAL_UNVERIFIED` 明确未满足原需求全范围。原 T/D/U/R/E 证据类型保留在 CSV/JSON，不能据它判断当前是否已实现。\n\n**游戏实测验证数：0。** 用户已返回只读诊断报告；没有从该 JSON 读取进度，也没有请求截图。\n\n'
for module in dict.fromkeys(x['module'] for x in f['items']):
 doc+='## '+module+'\n\n| 编号 | 需求 | v0.2 交付状态 | 原始验收条件 |\n|---|---|---|---|\n'
 for x in f['items']:
  if x['module']==module:doc+='| '+x['id']+' | '+x['requirement']+' | '+x['delivery_v02']+'：'+x['status']+' | '+x['acceptance']+' |\n'
 doc+='\n'
(R/'docs/功能范围与验收.md').write_text(doc)
# Save test provenance without turning fixture results into game compatibility.
result={'version':'0.2.0-alpha','as_of':'2026-09-13','compiler':'Roslyn 4.8.0-7.23558.1 on Mono 6.12.0.199','platform':'Linux cross-build; no Windows game runtime','lua_51_fixture_checks':126,'csharp_fixture_checks':86,'ui_smoke_windows':2,'real_steam_client_test':False,'real_game_test':False,'real_save_backup_restore_test':False,'legacy_collector_ps7_checks_historical':39}
(R/'release-tests/results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(collections.Counter(x['delivery_v02'] for x in f['items']))
