#!/usr/bin/env python3
"""Reproducible source build (not bit-for-bit deterministic across different compiler/SDKs).
Use Roslyn csc 4.8+ with .NET Framework 4.8 refs, or Mono refs for Linux cross-build.
python tools/build_release.py /path/to/csc.exe [--mono]
No download, no game installation, no Steam connection.
"""
from pathlib import Path
import json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
compiler=Path(sys.argv[1]).resolve()
cmd0=(['mono'] if '--mono' in sys.argv else [])+[str(compiler),'-nologo','-langversion:9','-optimize+','-deterministic+']
for mode in ['campaign','dlc_solo']:
 module='wd1kit_'+mode
 dst=ROOT/'payload'/module
 if dst.exists():shutil.rmtree(dst)
 scripts=dst/'workspace'/module;scripts.mkdir(parents=True)
 for f in ['core.lua','menu.lua','catalog.lua']:shutil.copyfile(ROOT/'src/Plugin'/f,scripts/f)
 (scripts/'receipt.lua').write_text('-- Unauthorised source template. The companion replaces this only after a verified backup.\nreturn {format=1,product="WD1KIT",mode="'+mode+'",allow_persistent=false}\n')
 entry='''-- Original WD1KIT entry point. No automatic cheats on load.
local mode = "%s"
local folder = "%s/"
if WD1KIT_ACTIVE and WD1KIT_ACTIVE.alive then
    if WD1KIT_ACTIVE.mode == mode then return end
    WD1KIT_ACTIVE:shutdown("MODE_SWITCH_REQUIRES_RESTART")
    if WD1KIT_ACTIVE.script then pcall(function() WD1KIT_ACTIVE.script:Remove() end) end
end
local create = dofile(folder .. "core.lua")
local catalog = dofile(folder .. "catalog.lua")
local receipt = dofile(folder .. "receipt.lua")
local c = create(_G, catalog, receipt, mode)
WD1KIT_ACTIVE = c
local ok = pcall(function() dofile(folder .. "menu.lua")(c, catalog, mode) end)
if not ok then c:shutdown("MENU_INIT_ERROR"); c:message("WD1KIT: incompatible host or menu error. No cheats enabled.") end
'''%(mode,module)
 (scripts/'entrypoint.lua').write_text(entry)
 (dst/'toolkit-owner.json').write_text(json.dumps({'Product':'WD1KIT','Module':module,'Version':'0.2.0-alpha'},indent=2)+'\n')
 manifest={'friendlyId':module,'name':'WD1 中文工具箱 · '+('本体' if mode=='campaign' else 'Bad Blood')+' · Alpha','author':'WD1 Toolkit project','priority':10,'description':'Original guarded test plugin. Not a verified finished trainer. Requires separate NexusTools host.','packs':[],'enabled':True,'version':'0.2.0','configVersion':1,'luaAutoStart':[module+'/entrypoint.lua'],'dominoAutoStart':[],'minTntVersion':'1.1.12','compatibleGameModes':[mode]}
 (dst/'modconfig.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
refs=['-r:System.dll','-r:System.Core.dll','-r:System.Drawing.dll','-r:System.Windows.Forms.dll','-r:System.Web.Extensions.dll']
sam=sorted(str(p) for p in (ROOT/'third_party/SAM.API').rglob('*.cs'))
subprocess.run(cmd0+['-target:library','-platform:x86','-unsafe','-out:'+str(ROOT/'WD1.SteamBridge.dll')]+sam,check=True)
manifest=ROOT/'src/app.manifest'
shared=[str(p) for p in (ROOT/'src/Shared').glob('*.cs')]
subprocess.run(cmd0+['-target:winexe','-platform:x64','-win32manifest:'+str(manifest),'-out:'+str(ROOT/'WD1-Toolkit.exe')]+refs+shared+[str(ROOT/'src/Companion/Program.cs')],check=True)
steam=sorted(str(p) for p in (ROOT/'src/Steam').glob('*.cs'))
schema=sorted(str(p) for p in (ROOT/'third_party/SAM.Schema').glob('*.cs'))
subprocess.run(cmd0+['-target:winexe','-platform:x86','-win32manifest:'+str(manifest),'-out:'+str(ROOT/'WD1-Achievements.exe'),'-r:'+str(ROOT/'WD1.SteamBridge.dll')]+refs+shared+steam+schema,check=True)
for name in ['WD1-Toolkit.exe','WD1-Achievements.exe']:
 (ROOT/(name+'.config')).write_text('<?xml version="1.0" encoding="utf-8"?><configuration><startup useLegacyV2RuntimeActivationPolicy="true"><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8"/></startup></configuration>\n')
print('Built: WD1-Toolkit.exe (x64), WD1-Achievements.exe (x86), WD1.SteamBridge.dll (x86).')
