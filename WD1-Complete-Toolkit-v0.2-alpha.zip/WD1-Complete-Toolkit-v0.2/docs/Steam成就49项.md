# Steam 49 项成就核对表

官方列表基准：[1](https://steamcommunity.com/stats/243470/achievements)。中文条件是解释性翻译，英文名称用于准确定位；ACH 编号仅为本工程编号，不是 Steam API 名称。

本体 39 项＋Bad Blood 10 项。按原始玩法，有 5 项本体成就与 1 项 DLC 合作成就需要多人游戏；其余 43 项的玩法条件可以单人完成。Steam/Ubisoft 的联网同步与“玩法需多人”不是一回事。

这份表只核对内容，没有读取你的账户，也没有点亮或修改任何成就。v0.2 随包提供独立成就流程，实际 API 名和权限仍需在你的本机读取；不能将工程序号用于写入，工具尚未在真实 Steam 会话测试。

| 工程编号 | 内容 | 英文成就名称 | 中文条件 | 原始玩法需多人 |
|---|---|---|---|---|
| ACH-001 | Base game | Hello World | 击倒 Maurice。 | 否 |
| ACH-002 | Base game | Bookmarked | 标记 100 名敌人。 | 否 |
| ACH-003 | Base game | Hard Crash | 完成 10 次车辆击毁/制服判定（vehicle takedown）。 | 否 |
| ACH-004 | Base game | Family Man | 完成本体第一幕。 | 否 |
| ACH-005 | Base game | Who Is Raymond Kenney? | 完成本体第二幕。 | 否 |
| ACH-006 | Base game | Black Hat Trick | 用同一个简易爆炸装置（IED）击杀 3 名敌人。 | 否 |
| ACH-007 | Base game | One Down, One to Go | 完成本体第三幕。 | 否 |
| ACH-008 | Base game | Vengeance | 完成本体第四幕。 | 否 |
| ACH-009 | Base game | Log Off | 完成本体第五幕。 | 否 |
| ACH-010 | Base game | Escape Loop | 摆脱 15 次警方追捕。 | 否 |
| ACH-011 | Base game | Hardware Fail | 射爆 15 辆不同车辆的轮胎。 | 否 |
| ACH-012 | Base game | Free Radical | 摆脱一次 5 级警方追捕。 | 否 |
| ACH-013 | Base game | Communication Fail | 以非致命击倒阻止 10 名平民打电话举报你。 | 否 |
| ACH-014 | Base game | Clear Signals | 解锁所有 ctOS 塔。 | 否 |
| ACH-015 | Base game | Magic Smoke | 在同一次专注（Focus）期间击杀 4 名敌人。 | 否 |
| ACH-016 | Base game | Enforcer | 利用犯罪侦测系统制止 20 名已确认的罪犯。 | 否 |
| ACH-017 | Base game | Basest Base | 完成所有帮派据点。 | 否 |
| ACH-018 | Base game | Darkness Looms | 完成失踪人口调查的最终任务。 | 否 |
| ACH-019 | Base game | Saturday Night Special | 完成武器交易调查的最终任务。 | 否 |
| ACH-020 | Base game | Revoking Client Privileges | 完成人口贩卖调查的最终任务。 | 否 |
| ACH-021 | Base game | Sanity Check | 收集全部 8 部一次性手机。 | 否 |
| ACH-022 | Bad Blood | T-Bone: Friends in Need | 完成 Bad Blood 第一幕。 | 否 |
| ACH-023 | Base game | Peephole | 完成所有隐私入侵活动。 | 否 |
| ACH-024 | Base game | Read-only | 完成二维码调查的最终任务。 | 否 |
| ACH-025 | Bad Blood | T-Bone: No Easy Fix | 完成 Bad Blood 第二幕。 | 否 |
| ACH-026 | Bad Blood | T-Bone: Pest Control | 完成 Bad Blood 第三幕。 | 否 |
| ACH-027 | Base game | They Call Him The Vigilante | 完成所有调查。 | 否 |
| ACH-028 | Base game | Road Rage | 完成所有犯罪车队任务。 | 否 |
| ACH-029 | Base game | Power Cycle | 参与 5 种不同的城市小游戏。 | 否 |
| ACH-030 | Base game | System Mangler | 完成所有 ctOS 入侵挑战（ctOS Breach）。 | 否 |
| ACH-031 | Base game | End of Line | 完成 40 次中间人合约（Fixer Contracts）。 | 否 |
| ACH-032 | Base game | Geolocated | 在每个城市热点签到。 | 否 |
| ACH-033 | Base game | Freeware | 解锁技能树中的全部技能。 | 否 |
| ACH-034 | Base game | Stealth Cookie | 在未被发现的情况下完成一次线上跟踪。 | 是 |
| ACH-035 | Bad Blood | T-Bone: Looking For Trouble | 完成 Bad Blood 的所有支线调查。 | 否 |
| ACH-036 | Base game | White Rabbit Object | 躲过 15 次警方扫描。 | 否 |
| ACH-037 | Base game | Scanproof | 躲过一次 5 级警方扫描。 | 否 |
| ACH-038 | Base game | Disk Space Full | 解锁 SongSneak 成就要求的全部歌曲。 | 否 |
| ACH-039 | Base game | Social Lubricant | 在全部 3 名喝酒游戏对手处完成第 10 级。 | 否 |
| ACH-040 | Base game | Hackification | 在线上入侵模式中成功骇入 10 次对方玩家。 | 是 |
| ACH-041 | Base game | Piggyback | 在线上跟踪模式中成功观察 10 次对方玩家。 | 是 |
| ACH-042 | Base game | Traced | 被其他玩家线上跟踪 5 次。 | 是 |
| ACH-043 | Bad Blood | T-Bone: Mob Ruled | 完成 20 次芝加哥南方俱乐部合约。 | 否 |
| ACH-044 | Bad Blood | T-Bone: Second Amendment | 完成 20 次民兵合约。 | 否 |
| ACH-045 | Bad Blood | T-Bone: Unfixable | 完成 20 次中间人合约（Bad Blood）。 | 否 |
| ACH-046 | Bad Blood | T-Bone: Full Circuit | 完成 29 次驾驶任务。 | 否 |
| ACH-047 | Base game | Superhighway | 完成 10 场公开线上竞速（Public Online Races）。 | 是 |
| ACH-048 | Bad Blood | T-Bone: Negative Eugenics | 引爆遥控车，一次击杀 4 名敌人。 | 否 |
| ACH-049 | Bad Blood | T-Bone: Tag Team | 完成 10 次合作任务。 | 是 |

## 容易混淆的项目

- `Superhighway` 明确要求公开线上赛事；普通单机竞速和 MOD 的 NPC 竞速不能仅凭玩法相似就计作完成。
- `Traced` 是被其他人跟踪 5 次；不是自己跟踪其他人 5 次。
- `Tag Team` 是合作任务；单人完成街头清扫合约不能直接当成合作次数。
- `Freeware` 要处理技能点、技能前置、技能已购状态与效果，不能只给很多技能点就承诺解锁。
- `Disk Space Full` 应核对可解锁歌曲及成就条件，而不是把音频文件个数当完成度。
- `Clear Signals` 的具体塔总数在旧攻略中有口径冲突；按游戏实际进度轮/数据库枚举，不写死错误的总数。

平台状态的处理必须另行验证：列出真实 API 名称、当前状态、可写权限、调用返回与重启后的回读结果。未实现时保持“未实现”，不展示伪成功提示。
