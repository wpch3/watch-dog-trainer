# Splice-CarUnlock-Into-NGM.ps1
# WD1 car-unlock splicer: injects the superset car DB (81165196) into the
# patch pair currently present in data_win64 (works on vanilla or NGM pair).
# Pure byte-level operation, no decompression. Backs up originals first.
param(
  [Parameter(Mandatory=$true)][string]$DataDir,
  [string]$BlobPath = "",
  [string]$ToolDir = ""
)

$ErrorActionPreference = "Stop"

# --- path hardening: strip stray quotes / trailing backslashes that come
# --- from cmd quoting (e.g. "D:\path\" -> D:\path")
function Clean-PathArg([string]$p) {
  if ($null -eq $p) { return "" }
  $p = $p.Trim()
  $p = $p.Trim('"')
  while ($p.EndsWith("\")) { $p = $p.Substring(0, $p.Length - 1) }
  return $p
}
$DataDir = Clean-PathArg $DataDir
$ToolDir = Clean-PathArg $ToolDir
$BlobPath = Clean-PathArg $BlobPath

if ($ToolDir -eq "") {
  if ($PSScriptRoot) { $ToolDir = $PSScriptRoot }
  else { $ToolDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
}
if ($BlobPath -eq "") { $BlobPath = Join-Path $ToolDir "car_db_81165196.bin" }

# NOTE: Windows PowerShell 5.1 parses hex literals >= 0x80000000 as Int32
# (0x81165196 becomes -2129243754). Always use the decimal form here.
$TARGET = [long]2165723542   # 0x81165196 (car DB entry name hash)
$MASK32 = [long]4294967295   # 0xFFFFFFFF
$script:SplicerVersion = "v1.2"
$script:BUF = New-Object byte[] 8388608

function U32([byte[]]$b, [long]$off) {
  return [long]([BitConverter]::ToUInt32($b, [int]$off))
}

function Read-Fat([string]$fatPath, [ref]$flags, [ref]$rows) {
  $fat = [System.IO.File]::ReadAllBytes($fatPath)
  if ($fat[0] -ne 0x33 -or $fat[1] -ne 0x54 -or $fat[2] -ne 0x41 -or $fat[3] -ne 0x46) {
    throw ("not a FAT3 archive: " + $fatPath)
  }
  $ver = U32 $fat 4
  if ($ver -ne 8) { throw ("unsupported FAT version " + $ver + " in " + $fatPath) }
  $flags.Value = (U32 $fat 8)
  $count = (U32 $fat 12)
  $rows.Value = New-Object System.Collections.Generic.List[object]
  for ($i = 0; $i -lt $count; $i++) {
    $o = 16 + $i * 16
    $h = U32 $fat $o
    $b = U32 $fat ($o + 4)
    $c = U32 $fat ($o + 8)
    $d = U32 $fat ($o + 12)
    $rows.Value.Add(@{
      "hash"   = $h
      "unc"    = (($b -shr 3) -band 0x1FFFFFFF)
      "scheme" = ($b -band 7)
      "comp"   = ($c -band 0x1FFFFFFF)
      "srcOff" = (($d -shl 3) -bor (($c -shr 29) -band 7))
      "isTarget" = $false
    })
  }
}

function Copy-Slice([System.IO.Stream]$src, [long]$srcOff, [System.IO.Stream]$dst, [long]$len) {
  $src.Position = $srcOff
  while ($len -gt 0) {
    $take = $script:BUF.Length
    if ($take -gt $len) { $take = $len }
    $n = $src.Read($script:BUF, 0, [int]$take)
    if ($n -le 0) { throw "unexpected end of data" }
    $dst.Write($script:BUF, 0, $n)
    $len = $len - $n
  }
}

function Process-Pair([string]$datPath, [string]$fatPath, [byte[]]$blob, [string]$toolDir) {
  $fl = [long]0
  $rows = $null
  Read-Fat $fatPath ([ref]$fl) ([ref]$rows)
  Write-Host ("  " + (Split-Path -Leaf $fatPath) + ": " + $rows.Count + " entries, flags 0x" + $fl.ToString("X8"))

  foreach ($stale in @(($datPath + ".new"), ($fatPath + ".new"))) {
    if ([System.IO.File]::Exists($stale)) {
      [System.IO.File]::Delete($stale)
      Write-Host ("  removed stale temp: " + (Split-Path -Leaf $stale))
    }
  }

  $datStream = [System.IO.File]::OpenRead($datPath)
  try {
    # locate target; export existing payload for deep-merge review if compressed
    $idx = -1
    for ($i = 0; $i -lt $rows.Count; $i++) {
      if ($rows[$i].hash -eq $TARGET) { $idx = $i; break }
    }
    if ($idx -ge 0) {
      $e = $rows[$idx]
      Write-Host ("  NOTE: target entry EXISTS in this pair (scheme " + $e.scheme + ", " + $e.comp + " B).")
      $ngmPayloadPath = Join-Path $toolDir "ngm_81165196_payload.bin"
      $sl = New-Object byte[] ([int]$e.comp)
      $datStream.Position = $e.srcOff
      $null = $datStream.Read($sl, 0, [int]$e.comp)
      [System.IO.File]::WriteAllBytes($ngmPayloadPath, $sl)
      Write-Host ("  Original payload saved -> " + $ngmPayloadPath)
      Write-Host "  Send that file back for a deep object-level merge check."
    }

    # build new entry list (replace in place, or insert sorted if absent)
    $newRows = New-Object System.Collections.Generic.List[object]
    $replaced = $false
    foreach ($r in $rows) {
      if ($r.hash -eq $TARGET) {
        $newRows.Add(@{
          "hash" = $r.hash; "unc" = [long]$blob.Length; "scheme" = [long]0;
          "comp" = [long]$blob.Length; "srcOff" = [long]0; "isTarget" = $true
        })
        $replaced = $true
      } else {
        $newRows.Add(@{
          "hash" = $r.hash; "unc" = $r.unc; "scheme" = $r.scheme;
          "comp" = $r.comp; "srcOff" = $r.srcOff; "isTarget" = $false
        })
      }
    }
    if (-not $replaced) {
      $ins = $newRows.Count
      for ($i = 0; $i -lt $newRows.Count; $i++) {
        if ($newRows[$i].hash -gt $TARGET) { $ins = $i; break }
      }
      $newRows.Insert($ins, @{
        "hash" = $TARGET; "unc" = [long]$blob.Length; "scheme" = [long]0;
        "comp" = [long]$blob.Length; "srcOff" = [long]0; "isTarget" = $true
      })
      Write-Host ("  target absent -> inserted at position " + $ins + " (sorted)")
    }

    # assign new offsets sequentially (srcOff keeps the OLD location)
    $cur = [long]0
    foreach ($r in $newRows) {
      $r["newOff"] = $cur
      $cur = $cur + $r["comp"]
    }
    $newSize = $cur

    # write new dat (streaming)
    $tmpDat = $datPath + ".new"
    if ([System.IO.File]::Exists($tmpDat)) { [System.IO.File]::Delete($tmpDat) }
    $out = [System.IO.File]::Create($tmpDat)
    try {
      foreach ($r in $newRows) {
        if ($r["isTarget"]) {
          $out.Write($blob, 0, $blob.Length)
        } else {
          Copy-Slice $datStream $r["srcOff"] $out $r["comp"]
        }
      }
    } finally { $out.Close() }

    # write new fat
    $tmpFat = $fatPath + ".new"
    $ms = New-Object System.IO.MemoryStream
    $bw = New-Object System.IO.BinaryWriter($ms)
    $bw.Write([byte[]]@(0x33,0x54,0x41,0x46))   # '3TAF'
    $bw.Write([uint32]8)
    $bw.Write([uint32]$fl)
    $bw.Write([uint32]$newRows.Count)
    foreach ($r in $newRows) {
      $bw.Write([uint32]($r["hash"] -band $MASK32))
      $bw.Write([uint32](((($r["unc"] -band 0x1FFFFFFF) -shl 3) -bor ($r["scheme"] -band 7))))
      $bw.Write([uint32](((($r["newOff"] -band 7) -shl 29) -bor ($r["comp"] -band 0x1FFFFFFF))))
      $bw.Write([uint32][Math]::Floor($r["newOff"] / 8))
    }
    $bw.Write([uint32]0)
    $bw.Flush()
    [System.IO.File]::WriteAllBytes($tmpFat, $ms.ToArray())
    $bw.Close()

    # verify: re-read fat, check hashes/order/sizes and target payload bytes
    $fl2 = [long]0
    $rows2 = $null
    Read-Fat $tmpFat ([ref]$fl2) ([ref]$rows2)
    if ($rows2.Count -ne $newRows.Count) { throw "verify: entry count mismatch" }
    for ($i = 0; $i -lt $rows2.Count; $i++) {
      if ($rows2[$i].hash -ne $newRows[$i].hash) { throw ("verify: order mismatch at " + $i) }
      if ($rows2[$i].comp -ne $newRows[$i].comp) { throw ("verify: comp mismatch at " + $i) }
      if ($rows2[$i].srcOff -ne $newRows[$i]["newOff"]) { throw ("verify: offset mismatch at " + $i) }
    }
    $nd = [System.IO.File]::OpenRead($tmpDat)
    try {
      foreach ($r in $rows2) {
        if ($r.srcOff + $r.comp -gt $newSize) { throw "verify: entry exceeds dat size" }
      }
      $t = $null
      foreach ($r in $rows2) { if ($r.hash -eq $TARGET) { $t = $r; break } }
      if ($null -eq $t) { throw "verify: target missing" }
      if ($t.scheme -ne 0 -or $t.unc -ne $blob.Length -or $t.comp -ne $blob.Length) {
        throw "verify: target entry fields wrong"
      }
      $back = New-Object byte[] $blob.Length
      $nd.Position = $t.srcOff
      $null = $nd.Read($back, 0, $blob.Length)
      for ($i = 0; $i -lt $blob.Length; $i++) {
        if ($back[$i] -ne $blob[$i]) { throw ("verify: target payload mismatch at byte " + $i) }
      }
    } finally { $nd.Close() }

    # backups + swap in
    foreach ($f in @($datPath, $fatPath)) {
      $bak = $f + ".carbak"
      if (-not [System.IO.File]::Exists($bak)) { Copy-Item $f $bak }
    }
    Copy-Item $tmpDat $datPath -Force
    Copy-Item $tmpFat $fatPath -Force
    Remove-Item $tmpDat -ErrorAction SilentlyContinue
    Remove-Item $tmpFat -ErrorAction SilentlyContinue
    Write-Host ("  OK: " + (Split-Path -Leaf $datPath) + " now " + $newSize + " B, " + $newRows.Count + " entries (backup .carbak kept)")
  } finally { $datStream.Close() }
}

function Write-ManifestDiff([string]$pairName, [string]$fatPath, [string]$manifestPath, [System.IO.StreamWriter]$rep) {
  $fl = [long]0
  $rows = $null
  Read-Fat $fatPath ([ref]$fl) ([ref]$rows)
  $van = @{}
  if ([System.IO.File]::Exists($manifestPath)) {
    foreach ($line in [System.IO.File]::ReadAllLines($manifestPath)) {
      if ($line.StartsWith("#") -or $line.Trim() -eq "") { continue }
      $p = $line.Split(",")
      $van[[uint32]([Convert]::ToUInt32($p[0], 16))] = @([long]$p[1], [long]$p[2], [long]$p[3])
    }
  }
  $diffs = 0
  foreach ($r in $rows) {
    $key = [uint32]($r.hash -band $MASK32)
    if (-not $van.ContainsKey($key)) {
      $rep.WriteLine($pairName + " EXTRA " + $key.ToString("x8") + " scheme=" + $r.scheme + " comp=" + $r.comp + " unc=" + $r.unc)
      $diffs++
    } else {
      $v = $van[$key]
      if ($v[0] -ne $r.scheme -or $v[1] -ne $r.comp -or $v[2] -ne $r.unc) {
        $rep.WriteLine($pairName + " DIFF  " + $key.ToString("x8") + " scheme=" + $r.scheme + "/" + $v[0] + " comp=" + $r.comp + "/" + $v[1] + " unc=" + $r.unc + "/" + $v[2])
        $diffs++
      }
    }
  }
  Write-Host ("  manifest diff vs vanilla (" + $pairName + "): " + $diffs + " entries")
}

# ---- main ----
Write-Host ("=== WD1 Car-Unlock Splicer (NGM-compatible) " + $script:SplicerVersion + " ===")
if (-not [System.IO.File]::Exists($BlobPath)) { throw ("blob not found: " + $BlobPath) }
$blob = [System.IO.File]::ReadAllBytes($BlobPath)
Write-Host ("car DB blob: " + $BlobPath + " (" + $blob.Length + " B)")

$patchDat = Join-Path $DataDir "patch.dat"
$patchFat = Join-Path $DataDir "patch.fat"
$p1Dat = Join-Path $DataDir "patch1.dat"
$p1Fat = Join-Path $DataDir "patch1.fat"
if (-not ([System.IO.File]::Exists($patchDat) -and [System.IO.File]::Exists($patchFat))) {
  throw ("patch.dat/patch.fat not found in " + $DataDir)
}
$hasPatch1 = ([System.IO.File]::Exists($p1Dat) -and [System.IO.File]::Exists($p1Fat))

# choose the pair that holds the target (patch1 wins if present there)
$usePatch1 = $false
if ($hasPatch1) {
  $fl = [long]0
  $rows = $null
  Read-Fat $p1Fat ([ref]$fl) ([ref]$rows)
  foreach ($r in $rows) {
    if ($r.hash -eq $TARGET) { $usePatch1 = $true; break }
  }
}

if ($usePatch1) {
  Write-Host "target entry lives in patch1 pair -> splicing there"
  Process-Pair $p1Dat $p1Fat $blob $ToolDir
} else {
  Write-Host "splicing into patch pair"
  Process-Pair $patchDat $patchFat $blob $ToolDir
}

# audit vs vanilla -> report for remote review
$repPath = Join-Path $ToolDir "ngm_diff_manifest.txt"
$rep = New-Object System.IO.StreamWriter($repPath, $false)
try {
  Write-ManifestDiff "patch" $patchFat (Join-Path $ToolDir "vanilla_manifest_patch.txt") $rep
  if ($hasPatch1) {
    Write-ManifestDiff "patch1" $p1Fat (Join-Path $ToolDir "vanilla_manifest_patch1.txt") $rep
  }
  $rep.WriteLine("# generated by Splice-CarUnlock-Into-NGM")
} finally { $rep.Close() }
Write-Host ("audit report -> " + $repPath)
Write-Host "DONE. If ngm_81165196_payload.bin was created above, send it back together with ngm_diff_manifest.txt."
