@echo off
rem Swap the wd1_cars mod variant. ASCII only.
setlocal EnableExtensions
set "TD=%~dp0"
if "%TD:~-1%"=="\" set "TD=%TD:~0,-1%"
echo Which variant should be active?
echo   1 = FULL  : 74 cars + police/madness + Speed_08 (the real unlock mod)
echo   2 = NATIVE: unmodified NGM car DB (neutral control, disables unlocks)
set /p "C=Type 1 or 2 and press Enter: "
if "%C%"=="1" set "V=full"
if "%C%"=="2" set "V=native"
if not defined V (
  echo Nothing selected.
  pause
  goto :eof
)
copy /y "%TD%variants\wd1_cars_%V%.dat" "%TD%wd1_cars.dat" >nul
copy /y "%TD%variants\wd1_cars_%V%.fat" "%TD%wd1_cars.fat" >nul
echo Active variant is now: %V%
echo Start the game and test. CRASH = run again and pick the other one.
pause
