@echo off
echo Removing WD1 patch2 files...
del /f /q "%~dp0patch2.dat" 2>nul
del /f /q "%~dp0patch2.fat" 2>nul
echo Done. Place this .cmd in data_win64 first.
pause
